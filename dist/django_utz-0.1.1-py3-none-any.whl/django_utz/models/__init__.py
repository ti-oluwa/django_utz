"""
Model mixins and signals for django_utz.
"""