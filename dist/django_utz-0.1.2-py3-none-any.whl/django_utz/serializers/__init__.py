"""
Module containing django rest framework serializers mixins and fields for the django_utz package.
"""