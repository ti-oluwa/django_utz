"""
Django template tags and filters for converting datetime fields to the user's timezone
"""